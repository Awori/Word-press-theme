  <?php
/**
 * The header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$container = get_theme_mod( 'understrap_container_type' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> <?php understrap_body_attributes(); ?>>
<?php do_action( 'wp_body_open' ); ?>
<div class="site" id="page">

	<!-- ******************* The Navbar Area ******************* -->
	<div id="wrapper-navbar">
	<div class="top-header">
		<div class="cointainer">
		  <div class="row">
			<div class ="col-lg-1">
				<a href="/">
				    <img src="<?php echo get_template_directory_uri();?>/img/logo.jpg"  alt="Logo">
                </a>
			</div>
            <div class ="col-lg-4">
				<div class="top-header-contact">
                 <a href="tel:4800073561"><i class ="fa fa-phone"></i> 4800073561 </a> 
				 <a href="mailto:info@eshop.com.ug"><i class ="fa fa-envelope-o"></i> info@eshop.com.ug</a>  


                </div>
            </div>
          </div>
		<div>
    </div>
		

		<nav id="main-nav" class="navbar navbar-expand-xl navbar-dark bg-primary" aria-labelledby="main-nav-label">

			


		<div class="container">		

		<div class="mobile-menu-dropdown">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
		 aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation', 'understrap' ); ?>">
		
	    <span>Menu</span> <i class="fa fa-bars"></i>
		</button>
        </div>
		<!--		 The WordPress Menu goes here -->
				<?php
				wp_nav_menu(
					array(
						'theme_location'  => 'primary',
						'container_class' => 'collapse navbar-collapse',
						'container_id'    => 'navbarNavDropdown',
						'menu_class'      => 'navbar-nav ml-auto',
						'fallback_cb'     => '',
						'menu_id'         => 'main-menu',
						'depth'           => 2,
						'walker'          => new Understrap_WP_Bootstrap_Navwalker(),
					)
				);
				?>
			
			</div><!-- .container -->
			

		</nav><!-- .site-navigation -->

	</div><!-- #wrapper-navbar end -->
