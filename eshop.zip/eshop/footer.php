<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$container = get_theme_mod( 'understrap_container_type' );
?>

<?php get_template_part( 'sidebar-templates/sidebar', 'footerfull' ); ?>

<div class="wrapper" id="wrapper-footer" style="background-color:blue !important; margin-top:250px;">

<div class="container">
<footer class="footer text-center py-2 theme-bg-dark" style="color:white !important;">
   <div class="row">
    <div class="col-md-6">
    <div class="footer-heading footer-3" style="display:flex">   
    <div class="row">
    <h2>Social Media Platforms</h2>

    <div class="col-md-12">
    <a href="#" style="color:white !important;">Instagram</a>
    </div>
    <div class="col-md-12">
    <a href="#" style="color:white !important;">Facebook</a>
    </div>
    <div class="col-md-12">
    <a href="#" style="color:white !important;">Twitter</a>
    </div>
    <div class="col-md-12">
    <a href="#" style="color:white !important;">Telegram</a>
    </div>
    </div>
    </div>
    </div>
    <div class="col-md-6">
    <div class="footer-heading footer-2">
    <div class="row">
    <h2>Want to know more</h2>

    <div class="col-md-12">
    <a href="#" style="color:white !important;">Terms of Service</a>
</div>
<div class="col-md-12">
    <a href="#" style="color:white !important;">Support</a>
</div>
    <div class="col-md-12">

    <a href="#" style="color:white !important;">Contact</a>
</div>
<div class="col-md-12">
    <a href="#" style="color:white !important;">Sponsorships</a>
</div>
<div class="col-md-12">
    <a href="#" style="color:white !important;">Jobs</a>
</div>
    </div>

</div>
    </div>

   </div>
    
</footer>
</div>
</div><!-- wrapper end -->

<div class="container justify-content-center">
<div class="copyright mx-auto justify-content-center" style="color:white !important;">
    <!-- <a href="#" >Copyright Eshop 2021 </a> -->
    <p style="color:black !important;" class="mx-auto">Copyright Eshop 2021 Website by Awori</p>
</div>
</div>
</div><!-- #page we need this extra closing tag here -->

<?php wp_footer(); ?>

</body>

</html>

